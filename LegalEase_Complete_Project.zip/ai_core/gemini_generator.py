import os
from dotenv import load_dotenv

load_dotenv()

try:
    import google.generativeai as genai
except ImportError:
    genai = None


class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

        if not self.api_key:
            raise RuntimeError(
                "GEMINI_API_KEY is missing. Add it to your .env file."
            )

        if genai is None:
            raise RuntimeError(
                "google-generativeai is not installed. Run pip install -r requirements.txt."
            )

        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel(self.model_name)

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: str,
        effective_date: str,
    ) -> str:
        prompt = f'''
You are the document-generation component of LegalEase.

Create a clear, professional LEGAL DOCUMENT DRAFT.

Document type:
{document_type}

Parties:
{parties}

Effective date:
{effective_date}

Terms and conditions:
{terms}

Instructions:
1. Use only the information supplied above. Do not invent names, addresses,
   money amounts, dates, laws, courts, registration numbers or other facts.
2. If important information is missing, use [TO BE COMPLETED] rather than
   inventing it.
3. Use a professional structure with a title, parties, effective date,
   numbered clauses, signatures and a short notice that this is a draft.
4. Preserve the supplied terms while improving organization and wording.
5. Do not claim that the document has been reviewed or approved by a lawyer.
6. Produce plain text suitable for editing and later export to DOCX/PDF.
'''

        response = self.model.generate_content(prompt)
        text = getattr(response, "text", None)

        if not text:
            raise RuntimeError("Gemini returned an empty response.")

        return text.strip()
